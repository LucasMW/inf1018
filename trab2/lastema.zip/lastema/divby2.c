int intdiv (int a, int b)
{
 return a/b;
}
int DivBy2(int a)
{
return intdiv(a,0xc1c2c3c4);
}

