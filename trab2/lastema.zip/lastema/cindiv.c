char chardiv (char a, char b)
{
 return a/b;
}
char InvDiv(int a, char b)
{
return chardiv(b,a);
}
